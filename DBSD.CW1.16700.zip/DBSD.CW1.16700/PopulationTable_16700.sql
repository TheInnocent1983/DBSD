-- Populating Supplier Table --
INSERT INTO Supplier (Name, ContactPerson, PhoneNumber, Email)
VALUES
    ('Yamaha', 'William Doe', '2345678901', 'yamaha.info@example.com'),
    ('Fender', 'Jane Smith', '3456789012', 'fender@example.com'),
    ('Steinway', 'Alice Brown', '4567890123', 'steinway@example.com'),
    ('Stradivarius', 'Bob Green', '5678901234', 'stradivarius@example.com'),
    ('Roland', 'Mark White', '6789012345', 'roland@example.com');

-- Populating CategoryManufacturer Table --
INSERT INTO CategoryManufacturer (Category, Manufacturer)
VALUES
    ('String', 'Fender'),
    ('Percussion', 'Yamaha'),
    ('Keyboard', 'Steinway'),
    ('Wind', 'Yamaha'),
    ('Electronic', 'Roland');

-- Populating Instrument Table --
INSERT INTO Instrument (InstrumentID, InstrumentName, Category, SupplierID)
VALUES
    (1, 'Guitar', 'String', 2),       -- SupplierID 2 corresponds to Fender
    (2, 'Drum Set', 'Percussion', 1),-- SupplierID 1 corresponds to Yamaha
    (3, 'Piano', 'Keyboard', 3),     -- SupplierID 3 corresponds to Steinway
    (4, 'Flute', 'Wind', 1),         -- SupplierID 1 corresponds to Yamaha
    (5, 'Synthesizer', 'Electronic', 5), -- SupplierID 5 corresponds to Roland
    (6, 'Violin', 'String', 4);      -- SupplierID 4 corresponds to Stradivarius

-- Populating Customer Table --
INSERT INTO Customer (FirstName, LastName, Email, PhoneNumber, Address)
VALUES 
    ('William', 'Doe', 'william.doe@example.com', '1234567890', '123 Elm St, NY'),
    ('Jane', 'Smith', 'jane.smith@example.com', '2345678901', '456 Maple St, NY'),
    ('Alice', 'Johnson', 'alice.johnson@example.com', '3456789012', '789 Oak St, NY'),
    ('Bob', 'Williams', 'bob.williams@example.com', '4567890123', '101 Pine St, NY'),
    ('Mary', 'Brown', 'mary.brown@example.com', '5678901234', '202 Birch St, NY');

-- Populating Rental Table --
INSERT INTO Rental (CustomerID, InstrumentID, RentalDate, ReturnDate)
VALUES
    (1, 1, GETDATE(), NULL), -- William rented a Guitar
    (2, 3, GETDATE(), NULL), -- Jane rented a Piano
    (3, 2, GETDATE(), NULL), -- Alice rented a Drum Set
    (4, 5, GETDATE(), NULL), -- Bob rented a Synthesizer
    (5, 6, GETDATE(), NULL); -- Mary rented a Violin

SELECT * FROM Supplier;

SELECT 
    i.InstrumentID,
    i.InstrumentName,
    i.Category,
    cm.Manufacturer,
    i.SupplierID
FROM 
    Instrument i
JOIN 
    CategoryManufacturer cm ON i.Category = cm.Category;
