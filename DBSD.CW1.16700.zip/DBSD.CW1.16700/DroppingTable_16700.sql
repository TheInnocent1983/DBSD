-- Drop tables in the correct order
DROP TABLE RentedInstrument;
DROP TABLE SoldInstrument;
DROP TABLE Maintenance;
DROP TABLE Sale;
DROP TABLE InstructorExpertise;
DROP TABLE Lesson;
DROP TABLE Rental;
DROP TABLE Instrument;
DROP TABLE Address;
DROP TABLE PhoneNumber;
DROP TABLE ExpertiseLevel;
DROP TABLE InstrumentType;
DROP TABLE Instructor;
DROP TABLE Customer;
DROP TABLE Supplier;
DROP TABLE CategoryManufacturer;